/* DRAKOB · service worker: chạy offline phần giao diện, không bao giờ lưu dữ liệu đăng nhập hay lời gọi AI */
const V = 'drakob-v1';
const SHELL = ['/', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png', '/icons/apple-touch-icon.png'];
const LIBS = ['https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js', 'https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.11/katex.min.css', 'https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.11/katex.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.11/contrib/mhchem.min.js'];
const LIB_HOSTS = ['cdnjs.cloudflare.com', 'cdn.jsdelivr.net', 'fonts.googleapis.com', 'fonts.gstatic.com', 'unpkg.com'];
const OFFLINE = '<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>Đang offline</title><body style="font:16px system-ui;background:#faf9f5;color:#1f1e1d;display:grid;place-items:center;height:100vh;margin:0;text-align:center"><div><h2>Đang offline</h2><p>Chưa có bản lưu của DRAKOB trên máy này.<br>Hãy kết nối mạng và mở lại một lần.</p></div>';

self.addEventListener('install', e => {
  e.waitUntil(caches.open(V).then(c => Promise.allSettled([...SHELL.map(u => c.add(u)), ...LIBS.map(u => c.add(new Request(u, { mode: 'cors' })))])));
});
self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== V) await caches.delete(k);
    await self.clients.claim();
  })());
});
self.addEventListener('message', e => { if (e.data === 'SKIP') self.skipWaiting(); });

const okRes = r => r && (r.ok || r.type === 'opaque');
async function put(req, res) { try { if (okRes(res)) { const c = await caches.open(V); await c.put(req, res.clone()) } } catch (e) {} return res }

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const u = new URL(req.url);
  if (req.headers.has('range')) return;
  // Trang chính: ưu tiên mạng (luôn mới), mất mạng thì dùng bản đã lưu
  if (req.mode === 'navigate' && u.origin === location.origin) {
    e.respondWith((async () => {
      try {
        const r = await fetch(req);
        if (r.ok) { const c = await caches.open(V); c.put('/', r.clone()) }
        return r;
      } catch (err) {
        const c = await caches.open(V);
        return (await c.match('/')) || new Response(OFFLINE, { status: 503, headers: { 'content-type': 'text/html; charset=utf-8' } });
      }
    })());
    return;
  }
  // Tệp tĩnh cùng nguồn: dùng bản lưu và cập nhật nền
  if (u.origin === location.origin) {
    if (u.pathname === '/sw.js') return;
    if (!/^\/(icons\/|manifest\.webmanifest$)/.test(u.pathname)) return;
    e.respondWith((async () => {
      const c = await caches.open(V), hit = await c.match(req);
      const net = fetch(req).then(r => put(req, r)).catch(() => hit);
      return hit || net;
    })());
    return;
  }
  // Thư viện từ CDN (có số phiên bản cố định): dùng bản lưu trước
  if (LIB_HOSTS.includes(u.hostname)) {
    e.respondWith((async () => {
      const c = await caches.open(V), hit = await c.match(req);
      if (hit) return hit;
      try { return await put(req, await fetch(req)) } catch (err) { return Response.error() }
    })());
  }
  // Mọi thứ khác (Supabase, API AI, ảnh…) đi thẳng, không qua bộ nhớ đệm
});
